// smoke.spec.js
// These are "smoke tests" — quick checks that make sure the most
// important parts of the TeachRight website are working.
// If any of these fail, it means something important is broken.

const { test, expect } = require('@playwright/test');

const SITE_URL = 'https://teachright.netlify.app';

test('Homepage loads successfully', async ({ page }) => {
  // Go to the website
  await page.goto(SITE_URL);

  // Check that the page title mentions "TeachRight"
  await expect(page).toHaveTitle(/TeachRight/);
});

test('Sign-in form is visible', async ({ page }) => {
  await page.goto(SITE_URL);

  // Check that key sign-in elements are visible on the page
  await expect(page.getByText('Sign In to TeachRight')).toBeVisible();
  await expect(page.getByPlaceholder('Email Address')).toBeVisible();
  await expect(page.getByPlaceholder('Password')).toBeVisible();
});

test('Sign-up link is visible and clickable', async ({ page }) => {
  await page.goto(SITE_URL);

  // Find the "Create one here" link and click it
  const signUpLink = page.getByText('Create one here');
  await expect(signUpLink).toBeVisible();
  await signUpLink.click();

  // After clicking, the "Create Your Teacher Account" text should appear
  await expect(page.getByText('Create Your Teacher Account')).toBeVisible();
});
