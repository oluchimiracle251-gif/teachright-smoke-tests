# TeachRight Smoke Tests — Step-by-Step Guide

This folder contains everything you need to complete your smoke testing
task. Follow these steps in order.

## What's in this folder
- `tests/smoke.spec.js` — the actual checks (tests) that run against the website
- `package.json` — a small file listing what tools are needed to run the tests
- `.github/workflows/smoke-test.yml` — tells GitHub to run the tests automatically
- `README.md` — this guide

## Step 1: Create a free GitHub account
Go to https://github.com and sign up (skip if you already have one).

## Step 2: Create a new repository (project space)
1. Click the "+" icon (top right) → "New repository"
2. Name it something like `teachright-smoke-tests`
3. Set it to **Public**
4. Click "Create repository"

## Step 3: Upload these files to your repository
1. On your new repository's page, click "Add file" → "Upload files"
2. Drag in ALL the files and folders from this project
   (make sure the `tests` folder and `.github` folder keep their names —
   GitHub should preserve the folder structure when you drag them in)
3. Click "Commit changes"

> Tip: If the `.github` folder doesn't show up when dragging, upload it
> separately, or use GitHub Desktop (a free app) which handles folders
> more reliably than the website uploader.

## Step 4: Watch it run automatically
1. Click the "Actions" tab at the top of your repository
2. You should see "Smoke Tests" running (a yellow dot = in progress)
3. Wait about 1-2 minutes
4. A green checkmark ✅ means all tests passed
5. A red X ❌ means something failed (click into it to see details)

## Step 5: Take your evidence
- Screenshot the green checkmark and the list of passed tests
  (click into the workflow run, then into "smoke-test" to see each
  test name with a checkmark next to it)
- This screenshot is your proof that the smoke tests ran successfully
  in a CI pipeline (GitHub Actions IS a CI system)

## Step 6: Write your short summary (for submission)
Example wording you can adapt:

> "I implemented automated smoke tests for the TeachRight website using
> Playwright. The tests check that the homepage loads, the sign-in form
> displays correctly, and the sign-up link works. These tests are
> connected to GitHub Actions, a Continuous Integration (CI) tool, so
> they run automatically every time code changes. This helps catch
> critical failures early, before a broken build reaches users."

## If a test fails
Click into the failed test in the Actions tab — it will show you
exactly which check didn't pass and why. This is normal and part of
learning; just note it down as part of your evidence too if needed.
